# SYNTHESIA VIDEO SCRIPTS

## Video 1: For Customers (Product Promo)
**Purpose:** Sell the Faceless YouTube Starter Pack  
**Length:** 60-90 seconds  
**Avatar:** Professional, friendly presenter  
**Background:** Clean office or tech-themed

---

### SYNTHESIA SCRIPT - Customer Video

**SCENE 1: HOOK (0-10 sec)**
```
Want to start a YouTube channel but hate being on camera?

[Pause]

What if I told you there's a way to build a profitable channel...
without ever showing your face?
```

**SCENE 2: PROBLEM (10-25 sec)**
```
Most people never start YouTube because:

They're camera shy...
They don't know what to talk about...
And they're overwhelmed by all the conflicting advice.

Sound familiar?
```

**SCENE 3: SOLUTION (25-45 sec)**
```
That's why I created the Faceless YouTube Starter Pack.

Inside, you get 40 ready-to-record video scripts.
Just fill in your niche and hit record.

Plus thumbnail templates that get clicks...
A monetization roadmap to $10K per month...
And AI tools that create content in minutes.
```

**SCENE 4: PROOF/OFFER (45-70 sec)**
```
Everything you need to launch in 24 hours.

Normally $149.
But for a limited time, just $9.99.

That's 40 scripts, templates, and guides...
for less than the price of lunch.

Click the link below to get instant access.
```

**SCENE 5: CTA (70-90 sec)**
```
30-day money-back guarantee.

So you have nothing to lose...
and a profitable YouTube channel to gain.

Click now. Your future audience is waiting.
```

---

## Video 2: For Sellers (Affiliate/Partner Promo)
**Purpose:** Get others to sell your product  
**Length:** 60-90 seconds  
**Avatar:** Business-focused presenter  
**Background:** Professional office

---

### SYNTHESIA SCRIPT - Seller/Affiliate Video

**SCENE 1: HOOK (0-10 sec)**
```
Want to make money online without creating a product?

[Pause]

I need partners to help me sell my Faceless YouTube course.
```

**SCENE 2: THE PRODUCT (10-30 sec)**
```
It's called the Faceless YouTube Starter Pack.

40 video scripts...
Thumbnail templates...
Complete monetization guide...

Everything someone needs to start a faceless channel.

And it sells for $9.99.
```

**SCENE 3: THE OFFER (30-55 sec)**
```
Here's the deal:

You promote it.
You keep 50% of every sale.
That's $5 per customer.

Sell 10 per day?
That's $1,500 per month.

Sell 100 per day?
That's $15,000 per month.
```

**SCENE 4: WHY IT SELLS (55-75 sec)**
```
Why does it convert so well?

The faceless YouTube trend is exploding.
Everyone wants passive income.
And at $9.99, it's an easy yes.

Plus, I give you everything:
Email swipes...
Social posts...
And video scripts.
```

**SCENE 5: CTA (75-90 sec)**
```
Click the link below to become a partner.

Start earning today.

See you on the inside.
```

---

## Video 3: Tutorial/Explainer
**Purpose:** Explain what's inside the course  
**Length:** 2-3 minutes  
**Avatar:** Friendly instructor  
**Background:** Clean, minimal

---

### SYNTHESIA SCRIPT - Explainer Video

**SCENE 1: INTRO (0-15 sec)**
```
Hi, I'm [Name], creator of the Faceless YouTube Starter Pack.

In the next 2 minutes, I'll show you exactly what you get...
so you can decide if it's right for you.
```

**SCENE 2: THE SCRIPTS (15-45 sec)**
```
First, you get 40 video scripts.

Not outlines. Not ideas.
Full scripts with hooks, body, and CTAs.

10 evergreen scripts that work year-round.
10 trending scripts for what's hot now.
10 engagement scripts to get comments.
10 AI scripts to leverage artificial intelligence.

Just fill in your niche and record.
```

**SCENE 3: THE GUIDES (45-75 sec)**
```
You also get complete guides:

The Quick Start guide gets you from zero...
to your first uploaded video in 24 hours.

The Monetization Roadmap shows you the path...
from $0 to $10,000 per month.

And the Setup Checklist ensures you don't miss anything.
```

**SCENE 4: TEMPLATES & TOOLS (75-100 sec)**
```
Plus, 20 thumbnail formulas.
These are proven designs that get clicks.

And analytics templates to track your growth.

Everything is organized, labeled, and ready to use.
```

**SCENE 5: WHO IT'S FOR (100-120 sec)**
```
This is perfect if:

You're camera shy...
You want passive income...
You don't know what content to make...
Or you want a proven system to follow.
```

**SCENE 6: PRICING & CTA (120-150 sec)**
```
The regular price is $149.

But right now, you can get everything...
all 40 scripts, all guides, all templates...
for just $9.99.

That's less than 25 cents per script.

Click the button below to get instant access.
Remember, it's backed by a 30-day guarantee.

I'll see you inside.
```

---

## HOW TO CREATE IN SYNTHESIA

### Step 1: Sign Up
1. Go to https://www.synthesia.io
2. Create account (free trial available)
3. Choose a plan (Starter is fine to begin)

### Step 2: Create New Video
1. Click "New Video"
2. Choose "Blank Canvas" or "From Template"
3. Select your avatar (recommend: professional, friendly)

### Step 3: Add Script
1. Copy one of the scripts above
2. Paste into Synthesia script box
3. Break into scenes (every 2-3 sentences = new scene)

### Step 4: Customize
1. **Background:** Choose clean office or abstract
2. **Branding:** Add your logo (if you have one)
3. **Text:** Add key points as on-screen text
4. **Music:** Add background music (subtle)

### Step 5: Generate
1. Click "Generate"
2. Wait for processing (5-10 minutes)
3. Download MP4

### Step 6: Use
1. **Customer Video:** Use on sales page, ads, social media
2. **Seller Video:** For affiliate recruitment, partner outreach
3. **Explainer:** For YouTube, landing pages, email marketing

---

## SYNTHESIA TIPS

### Best Practices:
- **Keep scenes short** (10-15 seconds max)
- **Use pauses** [Pause] in script for emphasis
- **Add captions** - many watch without sound
- **Include B-roll** - screen recordings, product shots
- **End with strong CTA** - tell them exactly what to do

### Cost Estimate:
- **Starter Plan:** $22/month = 10 videos
- **Creator Plan:** $67/month = 30 videos
- Each video can be up to 10 minutes

### Alternative Avatars (Free/Cheaper):
- **HeyGen** - Similar pricing, good quality
- **D-ID** - Pay per video, very affordable
- **Canva AI** - Included in Pro plan
- **Clipchamp** - Microsoft's free video editor with AI avatars

---

## VIDEO DISTRIBUTION STRATEGY

### Customer Video (Product Promo):
- **Sales page header** - Auto-play muted
- **YouTube ads** - Target "faceless YouTube" keywords
- **Facebook/Instagram ads** - Retargeting website visitors
- **TikTok** - Organic posts with product link

### Seller Video (Affiliate Recruitment):
- **Affiliate page** - Dedicated partner signup page
- **Email to potential affiliates** - Personal outreach
- **YouTube** - "Make money as my partner" video
- **LinkedIn** - B2B partner recruitment

### Explainer Video:
- **YouTube channel** - "What's inside" video
- **Email sequence** - Sent after opt-in
- **Gumroad description** - Embedded in product page
- **Blog posts** - Support written content

---

## QUICK START CHECKLIST

- [ ] Sign up for Synthesia (or HeyGen/D-ID)
- [ ] Choose avatar
- [ ] Copy script above
- [ ] Create first video
- [ ] Add to sales page
- [ ] Share on social media
- [ ] Create variations for testing

---

**Ready to create your AI spokesperson?** 🎬
