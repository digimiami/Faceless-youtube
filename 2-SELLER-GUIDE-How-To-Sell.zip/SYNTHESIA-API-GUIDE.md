# USING SYNTHESIA API (For Automation)

If you want to automate video creation instead of using the Synthesia web interface, here's how to use their API.

---

## Option 1: Synthesia API (Requires Coding)

### Step 1: Get API Key
1. Sign up at https://www.synthesia.io
2. Go to Account Settings → API
3. Generate API key
4. Save it securely

### Step 2: API Endpoint
```
POST https://api.synthesia.io/v2/videos
```

### Step 3: Sample Python Script
```python
import requests
import json

# Your API key
API_KEY = "your-api-key-here"

# API endpoint
url = "https://api.synthesia.io/v2/videos"

# Headers
headers = {
    "Authorization": API_KEY,
    "Content-Type": "application/json"
}

# Video configuration
payload = {
    "test": True,  # Set to False for real videos
    "visibility": "private",
    "aspectRatio": "16:9",
    "title": "Module 1 - Foundation",
    "description": "Faceless YouTube Course",
    "input": [
        {
            "avatarSettings": {
                "horizontalAlign": "center",
                "scale": 1,
                "style": "rectangular",
                "seamless": False
            },
            "background": "office",  # or custom color/image
            "avatar": "anna_costume1_cameraA",  # Choose avatar
            "script": "Welcome to the Faceless YouTube Starter Pack! I'm excited you're here...",
            "voice": "en-US-JennyMultilingualNeural"  # Voice selection
        }
    ]
}

# Make request
response = requests.post(url, headers=headers, json=payload)

# Check response
if response.status_code == 201:
    video_data = response.json()
    print(f"Video created! ID: {video_data['id']}")
    print(f"Status: {video_data['status']}")
else:
    print(f"Error: {response.status_code}")
    print(response.text)
```

### Step 4: Check Video Status
```python
video_id = "your-video-id"
url = f"https://api.synthesia.io/v2/videos/{video_id}"

response = requests.get(url, headers=headers)
status = response.json()

print(f"Status: {status['status']}")  # pending, in_progress, complete, error
if status['status'] == 'complete':
    print(f"Download URL: {status['download']}")
```

---

## Option 2: No-Code Alternative (Recommended)

If you don't want to code, use these tools:

### Make.com (formerly Integromat)
1. Sign up at https://make.com
2. Create new scenario
3. Add Synthesia module
4. Connect your account
5. Set up automation

### Zapier
1. Sign up at https://zapier.com
2. Create Zap with Synthesia
3. Trigger: New row in Google Sheets
4. Action: Create Synthesia video

---

## Cost Comparison

| Method | Cost | Effort |
|--------|------|--------|
| Web Interface | $22-67/month | Medium |
| API (Self-coded) | $22-67/month + dev time | High |
| Make.com/Zapier | $22-67/month + automation cost | Low |

---

## My Recommendation

**For 5 module videos:**

1. Use the **web interface** (easiest)
2. Copy-paste each scene from the scripts provided
3. Takes about 30 minutes per video
4. Total cost: $22-44 for one month

**Only use API if:**
- You're creating 50+ videos
- You need automated workflows
- You have a developer on your team

---

## Free Alternative

If Synthesia is too expensive right now:

### HeyGen Free Trial
- 1 free credit (1 minute video)
- Good for testing

### D-ID Trial
- 5 free videos
- Pay per video after ($6 each)

### Canva Pro
- AI avatars included
- $12.99/month
- Already have Canva? Use that!

---

## Scripts Ready to Use

The module video scripts in `SYNTHESIA-MODULE-VIDEOS.md` are formatted for easy copy-paste:

1. Copy each SCENE
2. Paste into Synthesia
3. Select avatar
4. Generate
5. Download
6. Repeat for next scene

**Total time to create all 5 videos: ~2-3 hours**

---

**Questions about Synthesia? Check their docs: https://docs.synthesia.io**
